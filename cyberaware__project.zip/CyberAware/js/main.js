// CyberAware: shared JavaScript for the website demonstration.
// This project uses browser storage only. It is not a real authentication system.

document.addEventListener("DOMContentLoaded", function () {
  // Highlight the current page in the navigation bar.
  const currentPage = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll("nav a").forEach(function (link) {
    if (link.getAttribute("href") === currentPage) link.classList.add("active");
  });

  // Registration form validation and demonstration account storage.
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;
      const confirmPassword = document.getElementById("confirmPassword").value;
      const message = document.getElementById("registerMessage");

      if (name.length < 2) {
        showMessage(message, "Please enter a valid name.", false); return;
      }
      if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) {
        showMessage(message, "Please enter a valid email address.", false); return;
      }
      if (password.length < 6) {
        showMessage(message, "Password must contain at least 6 characters.", false); return;
      }
      if (password !== confirmPassword) {
        showMessage(message, "Passwords do not match.", false); return;
      }

      // Demo only: never store real passwords in localStorage in a real application.
      localStorage.setItem("cyberAwareUser", JSON.stringify({ name: name, email: email }));
      showMessage(message, "Registration successful for this website demonstration!", true);
      registerForm.reset();
    });
  }

  // Quiz scoring.
  const quizForm = document.getElementById("cyberQuiz");
  if (quizForm) {
    quizForm.addEventListener("submit", function (event) {
      event.preventDefault();
      const answers = { q1: "b", q2: "a", q3: "c", q4: "b", q5: "a" };
      let score = 0;
      Object.keys(answers).forEach(function (question) {
        const selected = quizForm.querySelector('input[name="' + question + '"]:checked');
        if (selected && selected.value === answers[question]) score++;
      });
      const result = document.getElementById("quizResult");
      const percent = Math.round((score / 5) * 100);
      result.className = "result " + (score >= 3 ? "good" : "bad");
      result.textContent = "Your score: " + score + "/5 (" + percent + "%). " +
        (score >= 4 ? "Excellent cyber awareness!" :
        score >= 3 ? "Good effort. Keep learning safe online habits." :
        "Review the safety tips and try again.");
      localStorage.setItem("cyberAwareLastScore", String(score));
    });
  }

  // Identify-the-scam activity.
  document.querySelectorAll("[data-scam-answer]").forEach(function (button) {
    button.addEventListener("click", function () {
      const isSuspicious = button.dataset.scamAnswer === "suspicious";
      const result = button.closest(".panel").querySelector(".scamResult");
      result.className = "result scamResult " + (isSuspicious ? "good" : "bad");
      result.textContent = isSuspicious
        ? "That's right. Unexpected urgency, prize claims or requests for sensitive details are warning signs."
        : "Look carefully: unexpected links, urgent demands and requests for OTP/PIN are warning signs.";
    });
  });

  // Cybercrime guide: open the official Indian portal in a new tab.
  const reportButton = document.getElementById("openReportPortal");
  if (reportButton) {
    reportButton.addEventListener("click", function () {
      window.open("https://cybercrime.gov.in/", "_blank", "noopener");
    });
  }
});

function showMessage(element, message, success) {
  element.textContent = message;
  element.className = "result " + (success ? "good" : "bad");
}
