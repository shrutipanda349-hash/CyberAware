CYBERAWARE PROJECT

Included pages:
index.html, scams.html, examples.html, quiz.html, safety.html, report.html,
login.html, register.html, about.html
Shared files: css/style.css, js/main.js, images/cyber-shield.svg

HOW TO RUN:
1. Extract this ZIP file.
2. Open the CyberAware folder in Visual Studio Code.
3. Open index.html in a browser, or use the VS Code Live Server extension.

NOTE:
This is an educational frontend project. Scam examples are fictional.
Login and registration are demonstrations only; do not enter real passwords.
The project does not verify suspicious websites or messages in real time.
